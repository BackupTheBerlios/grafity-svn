"""Test cases for odrpack.

Anti-Copyright
==============

I hereby release this code into the PUBLIC DOMAIN AS IS.  There is no
support, warranty, or guarantee.  I will gladly accept comments, bug 
reports, and patches, however.

Robert Kern
kern@caltech.edu
"""


from odr import *
from odr.models import *
from Numeric import *
import cPickle


# First, let's do the three examples from the ODRPACK User's Guide

# Explicit Example

def expl_fcn(B, x, exp=exp, power=power):
    ret = B[0] + B[1] * power(exp(B[2]*x) - 1.0, 2)
    return ret

def expl_fjd(B, x, exp=exp):
    eBx = exp(B[2]*x)
    ret = B[1] * 2.0 * (eBx-1.0) * B[2] * eBx

    return ret

def expl_fjb(B, x, exp=exp, power=power, ones=ones, 
             asarray=asarray, Float=Float):
    eBx = exp(B[2]*x)
    
    res = concatenate((ones((x.shape[-1],), Float),
                       power(eBx-1.0, 2),
                       B[1]*2.0*(eBx-1.0)*eBx*x))
    res.shape = (3, x.shape[-1])

    return res

expl_mod = Model(expl_fcn, fjacb=expl_fjb, fjacd=expl_fjd, 
                 meta={'name':'Sample Explicit Model',
                       'ref':'ODRPACK UG, pg. 39'})

expl_dat = Data([0.,0.,5.,7.,7.5,10.,16.,26.,30.,34.,34.5,100.],
                [1265.,1263.6,1258.,1254.,1253.,1249.8,1237.,1218.,1220.6,
                 1213.8,1215.5,1212.])

expl_odr = ODR(expl_dat, expl_mod, beta0=[1500.0, -50.0, -0.1], 
               ifixx=[0,0,1,1,1,1,1,1,1,1,1,0])

expl_odr.set_job(deriv=2)



# Implicit Example

def impl_fcn(B, x, power=power):
    return B[2]*power(x[0]-B[0], 2) + 2.0*B[3]*(x[0]-B[0])*(x[1]-B[1]) + 
        B[4]*power(x[1]-B[1], 2) - 1.0

impl_mod = Model(impl_fcn, implicit=1, meta={'name': 'Sample Implicit Model',
                                             'ref': 'ODRPACK UG, pg. 49'})

impl_dat = Data([[0.5,1.2,1.6,1.86,2.12,2.36,2.44,2.36,2.06,1.74,1.34,
                  0.9,-0.28,-0.78,-1.36,-1.9,-2.5,-2.88,-3.18,-3.44],
                 [-0.12,-0.6,-1.,-1.4,-2.54,-3.36,-4.,-4.75,-5.25,-5.64,-5.97,
                  -6.32,-6.44,-6.44,-6.41,-6.25,-5.88,-5.5,-5.24,-4.86]],
                1)

impl_odr = ODR(impl_dat, impl_mod, beta0=[-1.0, -3.0, 0.09, 0.02, 0.08])



# Multi-variable Example

def multi_fcn(B, x, exp=exp, power=power, pi=3.141592653589793238462643383279, 
              concatenate=concatenate,
              sqrt=sqrt, arctan2=arctan2, cos=cos, sin=sin, odr_stop=odr_stop,
              less=less, sometrue=sometrue):
    if sometrue(less(x, 0.0)):
        raise odr_stop
    theta=pi*B[3]/2.
    ctheta = cos(theta)
    stheta = sin(theta)
    omega = power(2.*pi*x*exp(-B[2]), B[3])
    phi = arctan2((omega*stheta), (1.0 + omega*ctheta))
    r = (B[0] - B[1]) * power(sqrt(power(1.0 + omega*ctheta, 2) + \
         power(omega*stheta, 2)), -B[4])
    ret = concatenate((B[1] + r*cos(B[4]*phi), r*sin(B[4]*phi)))
    ret.shape = (2, x.shape[0])

    return ret
    
multi_mod = Model(multi_fcn, meta={'name': 'Sample Multi-Response Model',
                                   'ref': 'ODRPACK UG, pg. 56'})

multi_x = array([30.0, 50.0, 70.0, 100.0, 150.0, 200.0, 300.0, 500.0, 700.0, 
                 1000.0, 1500.0, 2000.0, 3000.0, 5000.0, 7000.0, 10000.0, 
                 15000.0, 20000.0, 30000.0, 50000.0, 70000.0, 100000.0, 
                 150000.0])
multi_y = array([[4.22, 4.167, 4.132, 4.038, 4.019, 3.956, 3.884, 3.784, 3.713, 
                  3.633, 3.54, 3.433, 3.358, 3.258, 3.193, 3.128, 3.059, 2.984, 
                  2.934, 2.876, 2.838, 2.798, 2.759], 
                 [0.136, 0.167, 0.188, 0.212, 0.236, 0.257, 0.276, 0.297, 0.309, 
                  0.311, 0.314, 0.311, 0.305, 0.289, 0.277, 0.255, 0.24, 0.218, 
                  0.202, 0.182, 0.168, 0.153, 0.139]])
multi_n = len(multi_x)
multi_we = zeros((2, 2, multi_n), Float)
multi_ifixx = ones((multi_n,))
multi_delta = zeros((multi_n,), Float)

multi_we[0,0,:] = 559.6
multi_we[1,0,:] = multi_we[0,1,:] = -1634.0
multi_we[1,1,:] = 8397.0

for i in range(multi_n):
    if multi_x[i] < 100.0:
        multi_ifixx[i] = 0
    elif multi_x[i] <= 150.0:
        pass # defaults are fine
    elif multi_x[i] <= 1000.0:
        multi_delta[i] = 25.0
    elif multi_x[i] <= 10000.0:
        multi_delta[i] = 560.0
    elif multi_x[i] <= 100000.0:
        multi_delta[i] = 9500.0
    else:
        multi_delta[i] = 144000.0
    if multi_x[i] == 100.0 or multi_x[i] == 150.0:
        multi_we[:,:,i] = 0.0

multi_dat = Data(multi_x, multi_y, wd=1e-4/power(multi_x, 2), we=multi_we)

multi_odr = ODR(multi_dat, multi_mod, beta0=[4.,2.,7.,.4,.5], 
                delta0=multi_delta, ifixx=multi_ifixx)
multi_odr.set_job(deriv=1, del_init=1)


# Pearson's Data
# K. Pearson, Philosophical Magazine, 2, 559 (1901)

p_x = array([0.,.9,1.8,2.6,3.3,4.4,5.2,6.1,6.5,7.4])
p_y = array([5.9,5.4,4.4,4.6,3.5,3.7,2.8,2.8,2.4,1.5])
p_sx = array([.03,.03,.04,.035,.07,.11,.13,.22,.74,1.])
p_sy = array([1.,.74,.5,.35,.22,.22,.12,.12,.1,.04])

p_we = 1./(p_sy*p_sy)
p_wd = 1./(p_sx*p_sx)

p_dat = Data(p_x, p_y, wd=p_wd, we=p_we)

# reverse the data to test invariance of results
pr_dat = Data(p_y, p_x, wd=p_we, we=p_wd)

def p_fcn(B, x):
    return B[0] + B[1]*x

p_mod = Model(p_fcn, meta={'name': 'Uni-linear Fit'})

p_odr = ODR(p_dat, p_mod, beta0=[1.,1.])
pr_odr = ODR(pr_dat, p_mod, beta0=[1.,1.])



# Lorentz Peak
# The data is taken from one of the undergraduate physics labs I performed.

def lorentz(beta, x):
    return beta[0]*beta[1]*beta[2] / sqrt(power(power(x, 2.0) - \
        beta[2]**2, 2.0) + power(beta[1]*x, 2.0))

l_sy = array([.29]*18)
l_sx = array([.000972971,.000948268,.000707632,.000706679,
              .000706074, .000703918,.000698955,.000456856,
              .000455207,.000662717,.000654619,.000652694,
              .000000859202,.00106589,.00106378,.00125483,
              .00140818,.00241839])

l_dat = Data([3.9094,3.85945,3.84976,3.84716,3.84551,3.83964,3.82608,
              3.78847,3.78163,3.72558,3.70274,3.6973,3.67373,3.65982,
              3.6562,3.62498,3.55525,3.41886],
             [652,910.5,984,1000,1007.5,1053,1160.5,1409.5,1430,
              1122,957.5,920,777.5,709.5,698,578.5,418.5,275.5],
             we=1./l_sy/l_sy,
             wd=1./l_sx/l_sx)

l_mod = Model(lorentz, meta={'name': 'Lorentz Peak'})

l_odr = ODR(l_dat, l_mod, beta0=(1000., .1, 3.8))


# Utility code

def outload(filename):
    """Load (via cPickle) cached Output instances."""

    f = open(filename)
    o = cPickle.load(f)
    f.close()

    return o

def outdump(obj, filename):
    """Dump (via cPickle) Output instance."""

    f = open(filename, 'w')
    cPickle.dump(obj, f)
    f.close()


# tests

def isclose(out1, out2, rtol=1.e-5, atol=1.e-8):
    """Test if the outputs are close enough."""

    attrs = ['beta', 'sd_beta', 'cov_beta']

    for attr in attrs:
        o1 = getattr(out1, attr)
        o2 = getattr(out2, attr)

        if not allclose(o1, o2, rtol, atol):
            print o1
            print o2
            print o1-o2
            raise odr_error, "%s's are different; rtol=%s, atol=%s" % (attr,
                rtol, atol)

    return 1
    
# map filenames to ODR instances

fn2odr = {'explicit.out': expl_odr,
          'implicit.out': impl_odr,
          'multi.out': multi_odr,
          'pearson.out': p_odr,
          'lorentz.out': l_odr}

def test():
    print 'Starting test...\n'

    for fn, fn_odr in fn2odr.items():
        print 'Trying %s' % fn_odr.model.name
        out1 = outload(fn)

        try:
            out2 = fn_odr.run()
            isclose(out1, out2)
            print 'Passed.'
        except odr_error, msg:
            print 'Failed: %s' % msg


if __name__ == '__main__':
    test()
