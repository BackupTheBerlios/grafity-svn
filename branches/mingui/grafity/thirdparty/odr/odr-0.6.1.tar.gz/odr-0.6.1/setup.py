# setup.py -- Distutils setup script for the odr package

# This file is in the PUBLIC DOMAIN.

from distutils.core import setup, Extension
from distutils import sysconfig
from distutils.ccompiler import new_compiler
from distutils.spawn import find_executable
import os


# Set opt_blas to 1 if you have an optimized BLAS and a 
# separately-compiled LINPACK. Edit the Extension instances
# below to reflect where your libraries are.

opt_blas = 1

# We need to compile FORTRAN files, so check if we would be
# using gcc anyways: then we can use g77 with impunity.
# Man, this is such a hack. I'm really, really sorry.

cc = new_compiler()
sysconfig.customize_compiler(cc)

if (os.name == 'nt' and find_executable('gcc') is not None) or \
   (cc.compiler[0] == 'gcc'):
    # we would be compiling with gcc; change it to g77

    old_cust_cc = sysconfig.customize_compiler

    def new_cust_cc(compiler):
        old_cust_cc(compiler)

        execs = ['compiler', 'linker_so', 'preprocessor', 
                 'compiler_so', 'linker_exe']
        if hasattr(compiler, 'linker_dll'):
            execs.append('linker_dll')

        for ex in execs:
            attr = getattr(compiler, ex)

            if attr is None:
                continue
            elif attr[0] == 'gcc':
                attr[0] = 'g77'
            elif attr == 'gcc':
                setattr(compiler, ex, 'g77')
            elif attr[0] == 'dllwrap':
                attr.append('-lg2c')
                
        compiler.src_extensions = compiler.src_extensions + ['.f']

    sysconfig.customize_compiler = new_cust_cc

    if opt_blas:
        # Optimized BLAS
        ext = Extension('__odrpack', 
                        ['src/__odrpack.c', 
                         'lib/d_odr.f',
                         'lib/d_mprec.f',
                         'lib/dlunoc.f',
                         'lib/d_lpk.f'],
                        libraries=['blas'],
                        library_dirs=['/usr/lib/atlas', '/usr/local/lib'],
                        include_dirs=['src'])
    else:
        # Unoptimized BLAS
        ext = Extension('__odrpack', 
                        ['src/__odrpack.c', 
                         'lib/d_odr.f',
                         'lib/d_mprec.f',
                         'lib/dlunoc.f',
                         'lib/d_lpkbls.f'],
                        include_dirs=['src'])

else:
    # Well, I'm stuck
    # What you can do is to compile the ODRPACK library yourself.
    # The source are in the lib subdirectory and a sample Makefile
    # is there. Edit the Makefile and compile. Change the Extension
    # instantiation in the setup() call to remove the FORTRAN files 
    # and add the options to link against that library.
    # Sorry I couldn't make this any easier.

    print 'Make sure libodrpack.a is has been compiled in ./lib'

    ext = Extension('__odrpack', 
                ['src/__odrpack.c'], 
                libraries=['odrpack'],
                library_dirs=['lib'],
                include_dirs=['src'])

    
setup(name='odr',
      version='0.6.1',
      description='Orthogonal Distance Regression package.',
      author='Robert Kern',
      author_email='rkern@ucsd.edu',
      url='http://starship.python.net/crew/kernr/Projects.html',
      licence="public domain",
      long_description="""odr interfaces with the FORTRAN-77 subroutine library
ODRPACK to provide non-linear, multidimensional orthogonal-distance 
regression over NumPy arrays.""",
#      platforms=["POSIX", "Windows"],

      packages=['odr'],
      package_dir={'odr': ''},

      ext_modules=[ext]
)      
      
