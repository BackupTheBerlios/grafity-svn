#!/usr/bin/env python

import os,sys,re
from distutils import dep_util
from glob import glob
import warnings

from scipy_distutils.core import Extension
from scipy_distutils.misc_util import get_path, default_config_dict, dot_join
from scipy_distutils.misc_util import fortran_library_item

from scipy_distutils.system_info import get_info,dict_append,\
     AtlasNotFoundError,LapackNotFoundError,BlasNotFoundError,\
     LapackSrcNotFoundError,BlasSrcNotFoundError

def configuration(parent_package=''):
    package = 'odr'
    config = default_config_dict(package,parent_package)
    local_path = get_path(__name__)

    libodr_files = ['d_odr.f',
                    'd_mprec.f',
                    'dlunoc.f']

    atlas_info = get_info('atlas')
    #atlas_info = {} # uncomment if ATLAS is available but want to use
                     # Fortran LAPACK/BLAS; useful for testing
    blas_libs = []
    if not atlas_info:
        warnings.warn(AtlasNotFoundError.__doc__)
        blas_info = get_info('blas')
        if blas_info:
            libodr_files.append('d_lpk.f')
            blas_libs.extend(blas_info['libraries'])
        else:
            warnings.warn(BlasNotFoundError.__doc__)
            libodr_files.append('d_lpkbls.f')
    else:
        libodr_files.append('d_lpk.f')
        blas_libs.extend(atlas_info['libraries'])
        
    libodr = [os.path.join(local_path, 'lib', x) for x in libodr_files]

    config['fortran_libraries'].append(('odr', {'sources':libodr}))
    sources = [os.path.join(local_path, 'src', '__odrpack.c')]
    ext = Extension(dot_join(parent_package,package,'__odrpack'),
                    sources,
                    libraries=['odr']+blas_libs,
                    include_dirs=[os.path.join(local_path,'src')],
                    library_dirs=atlas_info['library_dirs'],
                    )
    #ext.need_fcompiler_opts = 1
    config['ext_modules'].append(ext)
    
    return config

if __name__ == '__main__':
    from scipy_distutils.core import setup
    setup(**configuration())

